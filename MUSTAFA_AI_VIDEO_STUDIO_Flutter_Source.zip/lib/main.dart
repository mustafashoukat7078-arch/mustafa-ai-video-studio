import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:video_player/video_player.dart';

void main() => runApp(const MustafaStudioApp());

class MustafaStudioApp extends StatelessWidget {
  const MustafaStudioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'MUSTAFA AI VIDEO STUDIO',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090B16),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFF8B5CF6),
          brightness: Brightness.dark,
        ),
        useMaterial3: true,
      ),
      home: const StudioHome(),
    );
  }
}

class StudioHome extends StatefulWidget {
  const StudioHome({super.key});
  @override
  State<StudioHome> createState() => _StudioHomeState();
}

class _StudioHomeState extends State<StudioHome> {
  int tab = 0;
  final picker = ImagePicker();
  File? selectedVideo;
  File? selectedImage;
  VideoPlayerController? controller;
  final promptController = TextEditingController();
  final overlayController = TextEditingController();
  double brightness = 1;
  double contrast = 1;
  int duration = 10;
  String ratio = '16:9';
  String status = 'اپنا ویڈیو یا تصویر منتخب کریں';

  @override
  void dispose() {
    controller?.dispose();
    promptController.dispose();
    overlayController.dispose();
    super.dispose();
  }

  Future<void> pickVideo() async {
    try {
      final file = await picker.pickVideo(source: ImageSource.gallery);
      if (file == null) return;
      await controller?.dispose();
      final next = VideoPlayerController.file(File(file.path));
      await next.initialize();
      await next.setLooping(true);
      if (!mounted) return;
      setState(() {
        selectedVideo = File(file.path);
        controller = next;
        status = 'ویڈیو کامیابی سے منتخب ہوگئی';
      });
    } catch (e) {
      setState(() => status = 'ویڈیو کھولنے میں مسئلہ: $e');
    }
  }

  Future<void> pickImage() async {
    try {
      final file = await picker.pickImage(source: ImageSource.gallery);
      if (file == null) return;
      setState(() {
        selectedImage = File(file.path);
        status = 'تصویر کامیابی سے منتخب ہوگئی';
      });
    } catch (e) {
      setState(() => status = 'تصویر منتخب نہیں ہوسکی: $e');
    }
  }

  Widget panel({required Widget child}) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: const Color(0xFF15182A),
      borderRadius: BorderRadius.circular(20),
      border: Border.all(color: const Color(0xFF34304D)),
    ),
    child: child,
  );

  Widget actionButton(String text, IconData icon, VoidCallback action) =>
      SizedBox(
        width: double.infinity,
        child: FilledButton.icon(
          onPressed: action,
          icon: Icon(icon),
          label: Padding(
            padding: const EdgeInsets.symmetric(vertical: 12),
            child: Text(text),
          ),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('MUSTAFA AI VIDEO STUDIO',
          style: TextStyle(fontWeight: FontWeight.w900, fontSize: 16)),
        centerTitle: true,
        backgroundColor: const Color(0xFF111326),
      ),
      body: SafeArea(
        child: IndexedStack(
          index: tab,
          children: [editorPage(), aiPage()],
        ),
      ),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (v) => setState(() => tab = v),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.movie_edit), label: 'Editor'),
          NavigationDestination(icon: Icon(Icons.auto_awesome), label: 'AI Studio'),
        ],
      ),
    );
  }

  Widget editorPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('VIDEO EDITOR', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('اپنی گیلری سے ویڈیو منتخب کریں اور Preview دیکھیں۔'),
        const SizedBox(height: 14),
        actionButton('Upload Video', Icons.video_library, pickVideo),
        const SizedBox(height: 10),
        if (controller != null && controller!.value.isInitialized) ...[
          AspectRatio(
            aspectRatio: controller!.value.aspectRatio,
            child: VideoPlayer(controller!),
          ),
          Row(children: [
            IconButton(
              onPressed: () => setState(() {
                controller!.value.isPlaying ? controller!.pause() : controller!.play();
              }),
              icon: Icon(controller!.value.isPlaying ? Icons.pause : Icons.play_arrow),
            ),
            Expanded(child: VideoProgressIndicator(controller!, allowScrubbing: true)),
          ]),
        ] else Container(
          height: 170, alignment: Alignment.center,
          decoration: BoxDecoration(color: Colors.black26, borderRadius: BorderRadius.circular(14)),
          child: const Icon(Icons.video_file, size: 64, color: Colors.white38),
        ),
        const SizedBox(height: 8),
        Text(status, style: const TextStyle(color: Colors.white70)),
      ])),
      const SizedBox(height: 14),
      panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('QUICK ADJUSTMENTS', style: TextStyle(fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        Text('Brightness  ${(brightness * 100).round()}%'),
        Slider(value: brightness, min: 0.5, max: 1.5, onChanged: (v) => setState(() => brightness = v)),
        Text('Contrast  ${(contrast * 100).round()}%'),
        Slider(value: contrast, min: 0.5, max: 1.5, onChanged: (v) => setState(() => contrast = v)),
        TextField(controller: overlayController, decoration: const InputDecoration(labelText: 'Text overlay')),
        const SizedBox(height: 10),
        const Text('نوٹ: یہ ابتدائی ایڈیٹر UI ہے؛ ابھی اصل ویڈیو پر فلٹر لگا کر نئی فائل Export نہیں کرتا۔'),
      ])),
    ],
  );

  Widget aiPage() => ListView(
    padding: const EdgeInsets.all(16),
    children: [
      panel(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        const Text('AI VIDEO STUDIO', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const SizedBox(height: 8),
        const Text('Text-to-Video اور Image-to-Video کے لیے اپنا Prompt لکھیں۔'),
        const SizedBox(height: 14),
        SegmentedButton<String>(
          segments: const [
            ButtonSegment(value: 'Text-to-Video', label: Text('Text to Video')),
            ButtonSegment(value: 'Image-to-Video', label: Text('Image to Video')),
          ],
          selected: const {'Text-to-Video'},
          onSelectionChanged: (_) {},
        ),
        const SizedBox(height: 14),
        TextField(
          controller: promptController,
          minLines: 3,
          maxLines: 5,
          decoration: const InputDecoration(
            labelText: 'Describe your video',
            hintText: 'مثلاً: ایک خوبصورت پہاڑی منظر، سینیمیٹک انداز میں',
            border: OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 12),
        actionButton('Choose Image (for Image-to-Video)', Icons.image, pickImage),
        if (selectedImage != null) ...[
          const SizedBox(height: 10),
          ClipRRect(
            borderRadius: BorderRadius.circular(12),
            child: Image.file(selectedImage!, height: 150, fit: BoxFit.cover),
          ),
        ],
        const SizedBox(height: 10),
        Text('Duration: $duration seconds'),
        Slider(
          value: duration.toDouble(), min: 5, max: 600, divisions: 119,
          label: '$duration sec',
          onChanged: (v) => setState(() => duration = v.round()),
        ),
        DropdownButtonFormField<String>(
          value: ratio,
          decoration: const InputDecoration(labelText: 'Aspect ratio'),
          items: ['16:9', '9:16', '1:1'].map((v) => DropdownMenuItem(value: v, child: Text(v))).toList(),
          onChanged: (v) => setState(() => ratio = v ?? '16:9'),
        ),
        const SizedBox(height: 14),
        actionButton('Prepare AI Request', Icons.auto_awesome, () {
          final p = promptController.text.trim();
          setState(() => status = p.isEmpty
              ? 'پہلے Prompt لکھیں۔'
              : 'AI request تیار ہے۔ حقیقی ویڈیو بنانے کے لیے API اور Backend جوڑنا باقی ہے۔');
          showDialog(context: context, builder: (_) => AlertDialog(
            title: const Text('AI Request'),
            content: Text('Prompt: $p\\nDuration: $duration seconds\\nRatio: $ratio\\nImage selected: ${selectedImage != null}\\n\\nیہ صرف Request Preview ہے؛ ابھی AI ویڈیو Generate نہیں ہوگی۔'),
            actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
          ));
        }),
      ])),
      const SizedBox(height: 12),
      const Text('اہم: 10 منٹ کی ویڈیو کے لیے AI سروس کی اجازت، مناسب API، محفوظ Backend اور ممکنہ طور پر کئی clips کو جوڑنے کا نظام درکار ہوگا۔',
        style: TextStyle(color: Colors.white70)),
    ],
  );
}
