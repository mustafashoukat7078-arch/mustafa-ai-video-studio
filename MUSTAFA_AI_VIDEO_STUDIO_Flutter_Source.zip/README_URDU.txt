MUSTAFA AI VIDEO STUDIO - Flutter Starter Project

یہ Android کے لیے ابتدائی Flutter پروجیکٹ ہے۔

اہم:
- ویڈیو اور تصویر گیلری سے منتخب کرنے کی سہولت شامل ہے۔
- ویڈیو Preview اور Play/Pause شامل ہیں۔
- AI Studio میں Prompt، Duration اور Aspect Ratio کی Request Preview ہے۔
- ابھی اصل AI video generation، مکمل video editing/export، music، trim اور filters شامل نہیں ہیں۔
- اصل AI generation کے لیے محفوظ server/backend اور کسی AI video provider کی API درکار ہوگی۔
- API keys کو Flutter app کے اندر hard-code نہ کریں۔

Build کرنے کے لیے:
1. GitHub پر نیا repository بنائیں۔
2. اس ZIP کے اندر موجود تمام فائلیں repository میں upload کریں۔
3. Codemagic میں GitHub repository connect کریں۔
4. Flutter workflow منتخب کرکے Android APK build کریں۔
5. پہلی بار Codemagic کی موجودہ Flutter/Android build ہدایات کے مطابق Android project files مکمل generate/commit کرنا پڑ سکتا ہے۔

یہ مکمل تجارتی ایپ یا تیار APK نہیں بلکہ قابلِ توسیع starter source ہے۔
